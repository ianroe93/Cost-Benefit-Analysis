Please open HospitalDischargeBinary_St.ipynb. 
